GOV ARMANI SHOE CATALOGUE

Included:
- index.html: responsive black-and-gold catalogue
- No prices displayed
- Categories, search, size filter, stock status
- WhatsApp enquiry buttons connected to +2348024794787
- Add/remove shoes and upload photos in Manage Shoes
- Backup/restore catalogue JSON

IMPORTANT LIMITATION:
This is a working browser-based starter catalogue. Products added through Manage Shoes are stored only in that browser/device. They do not automatically appear on customers' phones. To make one public link with shared product uploads, the site needs hosting plus a shared database/image storage and a protected owner login. Do not publish this demo as a multi-user store and assume the local upload panel syncs across devices.

To preview:
1. Open index.html in Chrome.
2. Tap MANAGE SHOES to add product photos and details.
3. Use BACK UP CATALOGUE regularly to save a copy.

For a public launch, deploy the front end and connect a secure admin/database service before sharing the link widely.
